import { useState } from "react";
import { useClicksToday, useCreateClick } from "@/hooks/use-clicks";
import { ClickButton } from "@/components/ClickButton";
import { FeedbackCard } from "@/components/FeedbackCard";
import { HistoryList } from "@/components/HistoryList";
import { useToast } from "@/hooks/use-toast";
import type { Click } from "@shared/schema";

export default function Home() {
  const { data: clicks = [], isLoading } = useClicksToday();
  const { mutate: createClick, isPending } = useCreateClick();
  const { toast } = useToast();
  
  // State to track the last successful click for the feedback card
  const [lastClick, setLastClick] = useState<Click | null>(null);

  const handleButtonClick = (label: string) => {
    createClick({ buttonLabel: label }, {
      onSuccess: (data) => {
        setLastClick(data);
        toast({
          title: "Clique Registado!",
          description: `Você clicou em "${label}". Sequência: #${data.dailySequence}`,
          duration: 3000,
        });
      },
      onError: () => {
        toast({
          title: "Erro",
          description: "Não foi possível registar o clique. Tente novamente.",
          variant: "destructive",
        });
      }
    });
  };

  const buttons = [
    { label: "Botão 1", color: "bg-blue-50 text-blue-900 hover:bg-blue-100" },
    { label: "Botão 2", color: "bg-indigo-50 text-indigo-900 hover:bg-indigo-100" },
    { label: "Botão 3", color: "bg-purple-50 text-purple-900 hover:bg-purple-100" },
    { label: "Botão 4", color: "bg-rose-50 text-rose-900 hover:bg-rose-100" },
  ];

  return (
    <div className="min-h-screen bg-background selection:bg-primary/10 selection:text-primary">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
        
        {/* Header Section */}
        <header className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60">
            Registo de Cliques
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
            Sistema de monitorização diária. Clique nos botões abaixo para registar a atividade e acompanhar a sequência.
          </p>
        </header>

        {/* Buttons Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-8">
          {buttons.map((btn, index) => (
            <ClickButton
              key={btn.label}
              index={index}
              label={btn.label}
              colorClass={btn.color}
              onClick={() => handleButtonClick(btn.label)}
              disabled={isPending}
            />
          ))}
        </div>

        {/* Feedback Area */}
        <FeedbackCard click={lastClick} />

        {/* History Section */}
        <section className="mt-16 bg-white/50 rounded-3xl p-6 md:p-8 border border-white/40 shadow-sm backdrop-blur-sm">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold font-display">Registos de Hoje</h2>
            <div className="px-3 py-1 rounded-full bg-primary/5 text-primary text-sm font-medium">
              Total: {clicks.length}
            </div>
          </div>
          
          <HistoryList clicks={clicks} isLoading={isLoading} />
        </section>

      </div>
      
      {/* Decorative background elements */}
      <div className="fixed top-0 left-0 w-full h-full -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-100/30 rounded-full blur-3xl" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-100/30 rounded-full blur-3xl" />
      </div>
    </div>
  );
}
