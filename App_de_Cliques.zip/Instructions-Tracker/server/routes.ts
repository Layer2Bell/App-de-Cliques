
import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post(api.clicks.create.path, async (req, res) => {
    try {
      const input = api.clicks.create.input.parse(req.body);
      const click = await storage.addClick(input);
      res.status(201).json(click);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
        });
      }
      throw err;
    }
  });

  app.get(api.clicks.listToday.path, async (req, res) => {
    const clicks = await storage.getClicksToday();
    res.json(clicks);
  });

  app.get(api.clicks.stats.path, async (req, res) => {
    const stats = await storage.getClickStats();
    res.json(stats);
  });

  app.get(api.clicks.downloadToday.path, async (req, res) => {
    const clicks = await storage.getClicksToday();
    
    const today = new Date();
    const dateStr = today.toLocaleDateString("pt-PT", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
    
    let content = `Registo de Cliques - ${dateStr}\n`;
    content += "=".repeat(40) + "\n\n";
    
    if (clicks.length === 0) {
      content += "Nenhum clique registado hoje.\n";
    } else {
      clicks.forEach((click) => {
        const clickDate = new Date(click.createdAt);
        const timeStr = clickDate.toLocaleTimeString("pt-PT", {
          hour: "2-digit",
          minute: "2-digit",
        });
        content += `#${click.dailySequence} | ${click.buttonLabel} | ${timeStr}\n`;
      });
      content += "\n" + "=".repeat(40) + "\n";
      content += `Total de cliques: ${clicks.length}\n`;
    }
    
    const filename = `cliques_${today.toISOString().split("T")[0]}.txt`;
    
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(content);
  });

  // Seed data if empty
  const todayClicks = await storage.getClicksToday();
  if (todayClicks.length === 0) {
    console.log("Seeding database with past clicks...");
    // We can't easily insert past dates via the storage interface because it defaults to Now.
    // We'll skip complex seeding to avoid messing up the "daily sequence" logic demonstration.
    // The user can click to see it work.
  }

  return httpServer;
}
