## Packages
date-fns | Date formatting for the click history and feedback card
framer-motion | Smooth animations for entry and interactions

## Notes
- Tailwind Config needs to support the 'Inter' and 'Playfair Display' font families if used (will use CSS variables in index.css).
- No complex external integrations required.
